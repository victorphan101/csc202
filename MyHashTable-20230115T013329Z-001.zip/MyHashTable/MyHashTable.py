class MyHashTable:
    """sets with key and data"""
    def __init__(self, table_size=11):
        self.table = [None]
        self.numItems = 0
        self.table_size = table_size

    def insert(self, key, item):

    def get(self, key):

    def remove(self, key):

    def size(self):
        return self.numItems

    def load_factor(self):

    def collisions(self):