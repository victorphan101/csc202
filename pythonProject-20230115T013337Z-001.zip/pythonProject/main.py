# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print_hi('PyCharm')


# See PyCharm help at https://www.jetbrains.com/help/pycharm/


def indexOf(text, sub, index=0):
    if text[0:len(sub)] == sub:
        return 0
    if index == len(text):
        return -1
    if text[index:index + len(sub)] == sub:
        return index
    return indexOf(text, sub, index + 1)


print("The index is: ", indexOf("basketball", "bask"))
print("The index is: ", indexOf("basketball", "sket"))
print("The index is: ", indexOf("basketball", "ball"))
print("The index is: ", indexOf("basketball", "rop"))


def squareRoot(num, g=1):
    newGuess = (g + num / g) / 2
    if round(num - (newGuess * newGuess), 10) == 0:
        return newGuess

    return squareRoot(num, newGuess)


print(squareRoot(4))
print(squareRoot(9))
print(squareRoot(16))
print(squareRoot(25))
print(squareRoot(36))
