from unittest import TestCase
import main


class TestCaseSquareRoot(TestCase):
    def test_square_root_two(self):
        self.assertAlmostEqual(main.squareRoot(4), 2)

    def text_square_root_three(self):
        self.assertAlmostEqual(main.squareRoot(9), 3)

    def text_square_root_four(self):
        self.assertAlmostEqual(main.squareRoot(16), 4)

    def text_square_root_five(self):
        self.assertAlmostEqual(main.squareRoot(25), 5)

    def text_square_root_six(self):
        self.assertAlmostEqual(main.squareRoot(36), 6)


class Test(TestCase):
    def test_square_root(self):
        self.fail()
